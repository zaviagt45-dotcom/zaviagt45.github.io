"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Navigation from "@/components/Navigation"
import Footer from "@/components/Footer"
import { CheckCircle2, MapPin, Clock, Users, Star, Calendar, Utensils, Home, Bus } from "lucide-react"

export default function AventuraEconomicaPage() {
  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="relative h-[500px] flex items-center justify-center">
        <div className="absolute inset-0">
          <img
            src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/image-1764213018436.png?width=8000&height=8000&resize=contain"
            alt="Ruta del Sol"
            className="w-full h-full object-cover object-[center_65%]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent"></div>
        </div>
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <div className="flex items-center justify-center mb-4">
            <Star className="h-6 w-6 text-[#ffd700] fill-current drop-shadow-lg" />
            <Star className="h-6 w-6 text-[#ffd700] fill-current drop-shadow-lg" />
            <Star className="h-6 w-6 text-[#ffd700] fill-current drop-shadow-lg" />
          </div>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 text-white drop-shadow-[0_4px_16px_rgba(0,0,0,0.9)]">
            paquete Ruta del Sol
          </h1>
          <p className="text-2xl md:text-3xl text-white font-semibold drop-shadow-[0_3px_10px_rgba(0,0,0,0.9)]">
            2 días y 2 noches explorando El Salvador
          </p>
        </div>
      </section>

      {/* Quick Info */}
      <section className="py-8 px-4 bg-white border-b">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <Clock className="h-8 w-8 mx-auto mb-2 text-[#ffd700]" />
            <p className="font-semibold">2 días / 2 noches</p>
          </div>
          <div className="text-center">
            <Users className="h-8 w-8 mx-auto mb-2 text-[#ffd700]" />
            <p className="font-semibold">Grupo de 9 personas</p>
          </div>
          <div className="text-center">
            <MapPin className="h-8 w-8 mx-auto mb-2 text-[#ffd700]" />
            <p className="font-semibold">Múltiples destinos</p>
          </div>
          <div className="text-center">
            <Bus className="h-8 w-8 mx-auto mb-2 text-[#ffd700]" />
            <p className="font-semibold">Transporte en bus</p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 px-4 max-w-7xl mx-auto">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Description */}
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Descripción del Paquete</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed mb-4">
                Descubre la belleza de El Salvador con nuestro paquete Ruta del Sol. Perfecto para viajeros que buscan experiencias auténticas sin gastar de más. Visitarás el centro histórico de San Salvador, hermosas playas, y disfrutarás de la gastronomía típica salvadoreña.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Este paquete incluye transporte cómodo, hospedaje en Airbnb, y una deliciosa cena típica. Es ideal para familias, grupos de amigos, o viajeros que quieren explorar lo mejor de El Salvador en un fin de semana inolvidable.
              </p>
            </CardContent>
          </Card>

          {/* Itinerary */}
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Calendar className="h-6 w-6 text-[#ffd700]" />
                Itinerario
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Punto de Partida */}
                <div className="bg-[#f5e6d3] p-4 rounded-lg border-l-4 border-[#ffd700]">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-6 w-6 text-[#ffd700] flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-bold text-lg mb-1">Punto de Partida</h3>
                      <p className="text-gray-700">Casa Abril 15 calle 11-63 zona 1 Ciudad de Guatemala</p>
                    </div>
                  </div>
                </div>

                <div className="border-l-4 border-[#ffd700] pl-4">
                  <h3 className="font-bold text-lg mb-2">Día 1: Sábado - San Salvador</h3>
                  <ul className="space-y-1 text-gray-700">
                    <li>• <strong>Salida:</strong> 5:00 AM</li>
                    <li>• San Salvador Full Day</li>
                    <li>• Recorrido por el centro histórico</li>
                    <li>• Visita al área comercial</li>
                    <li>• <strong>Cena típica tradicional incluida</strong></li>
                    <li>• Hospedaje en Airbnb</li>
                  </ul>
                </div>

                <div className="border-l-4 border-[#ffd700] pl-4">
                  <h3 className="font-bold text-lg mb-2">Día 2: Domingo - Playa y Sol</h3>
                  <ul className="space-y-1 text-gray-700">
                    <li>• Costa del Sol</li>
                    <li>• Día completo de playa y piscinas</li>
                    <li>• Puerto La Libertad</li>
                    <li>• Visita a Sunset Park</li>
                    <li>• <strong>Cena en el muelle con vista al mar (no incluida)</strong></li>
                    <li>• Hospedaje en Airbnb</li>
                  </ul>
                </div>

                <div className="border-l-4 border-[#ffd700] pl-4">
                  <h3 className="font-bold text-lg mb-2">Día 3: Lunes - Regreso</h3>
                  <ul className="space-y-1 text-gray-700">
                    <li>• <strong>Regreso:</strong> 5:00 AM</li>
                    <li>• Llegada a punto de origen</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* What's Included */}
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Incluye</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ffd700] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Transporte en bus</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ffd700] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">3 noches de hospedaje en Airbnb</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ffd700] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Cena típica tradicional buffet ilimitado (Día 1)</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ffd700] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Guía durante traslados</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ffd700] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Hidratación ilimitada</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ffd700] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Servicio de toallas</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ffd700] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Servicio de palapas</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ffd700] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Acceso a playas y piscinas</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* What's NOT Included */}
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">No Incluye</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-gray-700">
                <p>• Alimentación</p>
                <p>• Pago único por ingreso para extranjeros de: $5 más presentación de pasaporte</p>
              </div>
            </CardContent>
          </Card>

          {/* Contact CTA */}
          <Card className="border-2 border-[#ffd700] bg-gradient-to-br from-[#ffd700]/10 to-[#ffd700]/5">
            <CardContent className="p-6 text-center">
              <h3 className="text-2xl font-bold mb-4">¿Interesado en este paquete?</h3>
              <p className="text-gray-700 mb-6">Contáctanos para más información y disponibilidad</p>
              <Link href="/contacto">
                <Button className="bg-[#ffd700] hover:bg-[#e6c200] text-black text-lg px-8 py-6">
                  Contactar Ahora
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  )
}