"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import Navigation from "@/components/Navigation"
import Footer from "@/components/Footer"
import { Phone, MapPin, MessageCircle, Clock, Send } from "lucide-react"
import { useState } from "react"
import { toast } from "sonner"

export default function ContactoPage() {
  const [formData, setFormData] = useState({
    name: "",
    packageName: "",
    phone: "",
    message: ""
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simular envío del formulario
    setTimeout(() => {
      toast.success("¡Mensaje enviado con éxito! Te contactaremos pronto.")
      setFormData({ name: "", packageName: "", phone: "", message: "" })
      setIsSubmitting(false)
    }, 1500)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="relative h-[300px] flex items-center justify-center bg-gradient-to-br from-[#ffd700] to-[#ff0066]">
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 text-white">
            Contáctanos
          </h1>
          <p className="text-xl text-white/90">
            Estamos aquí para ayudarte a planear tu viaje perfecto
          </p>
        </div>
      </section>

      {/* Contact Info Section */}
      <section className="py-16 px-4 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          <Card className="border-2 border-[#ffd700] hover:shadow-lg transition-shadow">
            <CardContent className="pt-6 text-center">
              <div className="w-16 h-16 rounded-full bg-[#ffd700] flex items-center justify-center mx-auto mb-4">
                <Phone className="h-8 w-8 text-black" />
              </div>
              <h3 className="font-bold text-lg mb-2">Teléfono</h3>
              <p className="text-gray-700 mb-1">+502 4838 1373</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-[#ff0066] hover:shadow-lg transition-shadow">
            <CardContent className="pt-6 text-center">
              <div className="w-16 h-16 rounded-full bg-[#ff0066] flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="h-8 w-8 text-white" />
              </div>
              <h3 className="font-bold text-lg mb-2">WhatsApp</h3>
              <p className="text-gray-700 mb-1">+502 4838 1373</p>
              <a
                href="https://wa.me/50248381373"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#ff0066] hover:underline text-sm"
              >
                Enviar mensaje
              </a>
              <p className="text-sm text-gray-500 mt-2">Respuesta inmediata</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-[#ffd700] hover:shadow-lg transition-shadow">
            <CardContent className="pt-6 text-center">
              <div className="w-16 h-16 rounded-full bg-[#ffd700] flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-black" />
              </div>
              <h3 className="font-bold text-lg mb-2">Oficina</h3>
              <p className="text-gray-700 mb-1">Casa Abril:</p>
              <p className="text-gray-700 mb-1">15 calle 11-63 zona 1</p>
              <p className="text-gray-700">Ciudad de Guatemala</p>
            </CardContent>
          </Card>
        </div>

        {/* Info Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Horarios */}
          <Card className="border-2 border-[#ff0066]">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Clock className="h-6 w-6 text-[#ff0066]" />
                Horarios de Atención
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between border-b pb-2">
                <span className="font-semibold">Lunes - Viernes:</span>
                <span className="text-gray-700">10:30 AM - 9:00 PM</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="font-semibold">Sábado:</span>
                <span className="text-gray-700">10:30 AM - 9:00 PM</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="font-semibold">Domingo:</span>
                <span className="text-gray-700">10:30 AM - 9:00 PM</span>
              </div>
              <div className="flex justify-between">
                <span className="font-semibold">WhatsApp:</span>
                <span className="text-[#ff0066]">24/7 Disponible</span>
              </div>
            </CardContent>
          </Card>

          {/* Ubicación */}
          <Card className="border-2 border-[#ffd700]">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <MapPin className="h-6 w-6 text-[#ffd700]" />
                Casa Abril
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-4">
                <strong>Dirección:</strong><br />
                15 calle 11-63 zona 1<br />
                Ciudad de Guatemala
              </p>
              <div className="aspect-video bg-gray-200 rounded-lg overflow-hidden">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3861.0863407744916!2d-90.51397052423795!3d14.644317277522087!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8589a3d0c7c3d3d3%3A0x8b7be88e6b3c6c6a!2sCiudad%20de%20Guatemala%2C%20Guatemala!5e0!3m2!1sen!2sus!4v1234567890123"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                ></iframe>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Formulario de Contacto y Ayuda Inmediata */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Formulario de Contacto */}
          <Card className="border-2 border-[#ffd700] lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Send className="h-6 w-6 text-[#ffd700]" />
                Enviar Mensaje
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-2">
                      Nombre completo
                    </label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Tu nombre"
                      required
                      className="border-[#ffd700]/50 focus:border-[#ffd700]"
                    />
                  </div>
                  <div>
                    <label htmlFor="packageName" className="block text-sm font-medium mb-2">
                      Paquete de interés
                    </label>
                    <select
                      id="packageName"
                      name="packageName"
                      value={formData.packageName}
                      onChange={handleChange}
                      required
                      className="flex h-10 w-full rounded-md border border-[#ffd700]/50 bg-background px-3 py-2 text-sm ring-offset-background focus:border-[#ffd700] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/50 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <option value="">Selecciona un paquete</option>
                      <option value="aventura-economica">Aventura Económica</option>
                      <option value="experiencia-premium">Experiencia Premium</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium mb-2">
                    Teléfono
                  </label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+502 1234 5678"
                    required
                    className="border-[#ffd700]/50 focus:border-[#ffd700]"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-2">
                    Mensaje
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Cuéntanos sobre tu viaje ideal..."
                    rows={5}
                    required
                    className="border-[#ffd700]/50 focus:border-[#ffd700]"
                  />
                </div>
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-[#ffd700] hover:bg-[#ffaa00] text-black font-semibold"
                >
                  {isSubmitting ? (
                    "Enviando..."
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Enviar Mensaje
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Ayuda Inmediata */}
          <Card className="border-2 border-[#ff0066] bg-gradient-to-br from-[#ff0066]/10 to-[#ffd700]/10">
            <CardContent className="pt-6">
              <h3 className="font-bold text-lg mb-2">¿Necesitas ayuda inmediata?</h3>
              <p className="text-gray-700 mb-4">
                Nuestro equipo está disponible en WhatsApp para responderte al instante.
              </p>
              <a
                href="https://wa.me/50248381373"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="w-full bg-[#ff0066] hover:bg-[#cc0052] text-white">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Abrir WhatsApp
                </Button>
              </a>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  )
}