"use client"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import Navigation from "@/components/Navigation"
import Footer from "@/components/Footer"
import { CreditCard, Users, Calendar, ShoppingCart, CheckCircle2, AlertCircle } from "lucide-react"

const packages = {
  "aventura-economica": {
    name: "Aventura Económica",
    price: 699,
    duration: "3 días / 2 noches",
    color: "#ffd700"
  },
  "experiencia-premium": {
    name: "Experiencia Premium",
    price: 1499,
    duration: "5 días / 4 noches",
    color: "#ff0066"
  }
}

export default function ComprarPage() {
  const searchParams = useSearchParams()
  const defaultPackage = searchParams.get("paquete") || "aventura-economica"
  
  const [selectedPackage, setSelectedPackage] = useState(defaultPackage)
  const [numPassengers, setNumPassengers] = useState(1)
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    date: "",
    passengers: 1,
    paymentMethod: "tarjeta"
  })

  const currentPackage = packages[selectedPackage as keyof typeof packages]
  const subtotal = currentPackage.price * numPassengers
  const tax = subtotal * 0.13 // 13% IVA
  const total = subtotal + tax

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (step === 1) {
      setStep(2)
    } else {
      alert("¡Reserva confirmada! Te enviaremos un correo con los detalles.")
      // Here you would normally process the payment
    }
  }

  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="relative h-[250px] flex items-center justify-center bg-gradient-to-br from-[#ff0066] via-[#ffd700] to-[#ff0066]">
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <ShoppingCart className="h-12 w-12 mx-auto mb-4 text-white" />
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">
            Comprar Paquete
          </h1>
          <p className="text-lg text-white/90">
            Completa tu reserva en 2 simples pasos
          </p>
        </div>
      </section>

      {/* Progress Indicator */}
      <section className="py-6 px-4 bg-white border-b">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-center space-x-4">
            <div className={`flex items-center ${step >= 1 ? 'text-[#ff0066]' : 'text-gray-400'}`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-[#ff0066]' : 'bg-gray-300'} text-white font-bold`}>
                1
              </div>
              <span className="ml-2 hidden sm:inline font-semibold">Información</span>
            </div>
            <div className="w-16 h-1 bg-gray-300">
              <div className={`h-full ${step >= 2 ? 'bg-[#ff0066]' : 'bg-gray-300'} transition-all`}></div>
            </div>
            <div className={`flex items-center ${step >= 2 ? 'text-[#ff0066]' : 'text-gray-400'}`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-[#ff0066]' : 'bg-gray-300'} text-white font-bold`}>
                2
              </div>
              <span className="ml-2 hidden sm:inline font-semibold">Pago</span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 px-4 max-w-7xl mx-auto">
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Form */}
            <div className="lg:col-span-2 space-y-6">
              {step === 1 ? (
                <>
                  {/* Package Selection */}
                  <Card className="border-2 border-[#ffd700]">
                    <CardHeader>
                      <CardTitle className="text-2xl flex items-center gap-2">
                        <ShoppingCart className="h-6 w-6 text-[#ffd700]" />
                        Selecciona tu Paquete
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <RadioGroup value={selectedPackage} onValueChange={setSelectedPackage}>
                        <div className="space-y-4">
                          <div className="flex items-center space-x-3 border-2 border-[#ffd700] rounded-lg p-4 cursor-pointer hover:bg-[#ffd700]/5">
                            <RadioGroupItem value="aventura-economica" id="aventura" />
                            <Label htmlFor="aventura" className="flex-1 cursor-pointer">
                              <div className="flex justify-between items-center">
                                <div>
                                  <p className="font-bold text-lg">Aventura Económica</p>
                                  <p className="text-sm text-gray-600">3 días / 2 noches</p>
                                </div>
                                <p className="text-2xl font-bold text-[#ffd700]">Q699</p>
                              </div>
                            </Label>
                          </div>

                          <div className="flex items-center space-x-3 border-2 border-[#ff0066] rounded-lg p-4 cursor-pointer hover:bg-[#ff0066]/5">
                            <RadioGroupItem value="experiencia-premium" id="premium" />
                            <Label htmlFor="premium" className="flex-1 cursor-pointer">
                              <div className="flex justify-between items-center">
                                <div>
                                  <p className="font-bold text-lg">Experiencia Premium</p>
                                  <p className="text-sm text-gray-600">5 días / 4 noches</p>
                                </div>
                                <p className="text-2xl font-bold text-[#ff0066]">Q1,499</p>
                              </div>
                            </Label>
                          </div>
                        </div>
                      </RadioGroup>
                    </CardContent>
                  </Card>

                  {/* Number of Passengers */}
                  <Card className="border-2 border-[#ff0066]">
                    <CardHeader>
                      <CardTitle className="text-2xl flex items-center gap-2">
                        <Users className="h-6 w-6 text-[#ff0066]" />
                        Número de Pasajeros
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center space-x-4">
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => setNumPassengers(Math.max(1, numPassengers - 1))}
                          className="h-12 w-12 border-[#ff0066]"
                        >
                          -
                        </Button>
                        <div className="flex-1 text-center">
                          <p className="text-4xl font-bold text-[#ff0066]">{numPassengers}</p>
                          <p className="text-sm text-gray-600">
                            {numPassengers === 1 ? "pasajero" : "pasajeros"}
                          </p>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => setNumPassengers(numPassengers + 1)}
                          className="h-12 w-12 border-[#ff0066]"
                        >
                          +
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Personal Information */}
                  <Card className="border-2 border-[#ffd700]">
                    <CardHeader>
                      <CardTitle className="text-2xl">Información Personal</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Nombre Completo *</Label>
                        <Input
                          id="name"
                          placeholder="Juan Pérez"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="border-[#ffd700]"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email">Email *</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="juan@email.com"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className="border-[#ffd700]"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone">Teléfono *</Label>
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="+502 1234-5678"
                          required
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="border-[#ffd700]"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="date" className="flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          Fecha de Viaje Preferida *
                        </Label>
                        <Input
                          id="date"
                          type="date"
                          required
                          value={formData.date}
                          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                          className="border-[#ffd700]"
                        />
                        <p className="text-sm text-gray-600">
                          Confirmaremos disponibilidad para esta fecha
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </>
              ) : (
                <>
                  {/* Payment Method */}
                  <Card className="border-2 border-[#ff0066]">
                    <CardHeader>
                      <CardTitle className="text-2xl flex items-center gap-2">
                        <CreditCard className="h-6 w-6 text-[#ff0066]" />
                        Método de Pago
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <RadioGroup value={formData.paymentMethod} onValueChange={(value) => setFormData({ ...formData, paymentMethod: value })}>
                        <div className="space-y-4">
                          <div className="flex items-center space-x-3 border-2 border-[#ff0066] rounded-lg p-4 cursor-pointer hover:bg-[#ff0066]/5">
                            <RadioGroupItem value="tarjeta" id="tarjeta" />
                            <Label htmlFor="tarjeta" className="flex-1 cursor-pointer">
                              <div className="flex items-center gap-2">
                                <CreditCard className="h-5 w-5 text-[#ff0066]" />
                                <span className="font-semibold">Tarjeta de Crédito/Débito</span>
                              </div>
                            </Label>
                          </div>

                          <div className="flex items-center space-x-3 border-2 border-gray-300 rounded-lg p-4 cursor-pointer hover:bg-gray-50">
                            <RadioGroupItem value="transferencia" id="transferencia" />
                            <Label htmlFor="transferencia" className="flex-1 cursor-pointer">
                              <span className="font-semibold">Transferencia Bancaria</span>
                            </Label>
                          </div>

                          <div className="flex items-center space-x-3 border-2 border-gray-300 rounded-lg p-4 cursor-pointer hover:bg-gray-50">
                            <RadioGroupItem value="efectivo" id="efectivo" />
                            <Label htmlFor="efectivo" className="flex-1 cursor-pointer">
                              <span className="font-semibold">Efectivo (en oficina)</span>
                            </Label>
                          </div>
                        </div>
                      </RadioGroup>

                      {formData.paymentMethod === "tarjeta" && (
                        <div className="mt-6 space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="cardNumber">Número de Tarjeta *</Label>
                            <Input
                              id="cardNumber"
                              placeholder="1234 5678 9012 3456"
                              required
                              className="border-[#ff0066]"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor="expiry">Vencimiento *</Label>
                              <Input
                                id="expiry"
                                placeholder="MM/AA"
                                required
                                className="border-[#ff0066]"
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="cvv">CVV *</Label>
                              <Input
                                id="cvv"
                                placeholder="123"
                                required
                                maxLength={3}
                                className="border-[#ff0066]"
                              />
                            </div>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="cardName">Nombre en la Tarjeta *</Label>
                            <Input
                              id="cardName"
                              placeholder="JUAN PEREZ"
                              required
                              className="border-[#ff0066]"
                            />
                          </div>
                        </div>
                      )}

                      {formData.paymentMethod === "transferencia" && (
                        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                          <p className="font-semibold mb-2">Datos para Transferencia:</p>
                          <p className="text-sm">Banco: Banco Industrial</p>
                          <p className="text-sm">Cuenta: 1234-5678-9012</p>
                          <p className="text-sm">A nombre de: Zavia Tours S.A.</p>
                          <p className="text-sm mt-2 text-gray-600">Envía el comprobante a: pagos@zavia.com</p>
                        </div>
                      )}

                      {formData.paymentMethod === "efectivo" && (
                        <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                          <p className="font-semibold mb-2">Pago en Oficina:</p>
                          <p className="text-sm">Dirección: Zona 10, Ciudad de Guatemala</p>
                          <p className="text-sm">Horario: Lunes a Viernes, 8:00 AM - 6:00 PM</p>
                          <p className="text-sm mt-2 text-gray-600">Reserva tu cupo ahora, paga después</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Terms and Conditions */}
                  <Card className="border-2 border-[#ffd700]">
                    <CardContent className="pt-6">
                      <div className="flex items-start space-x-2">
                        <input
                          type="checkbox"
                          id="terms"
                          required
                          className="mt-1"
                        />
                        <Label htmlFor="terms" className="text-sm cursor-pointer">
                          Acepto los términos y condiciones. He leído y estoy de acuerdo con la política de cancelación y reembolso. Entiendo que la confirmación de mi reserva está sujeta a disponibilidad.
                        </Label>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}

              {/* Action Buttons */}
              <div className="flex gap-4">
                {step === 2 && (
                  <Button
                    type="button"
                    variant="outline"
                    size="lg"
                    onClick={() => setStep(1)}
                    className="flex-1 border-gray-300"
                  >
                    Atrás
                  </Button>
                )}
                <Button
                  type="submit"
                  size="lg"
                  className={`flex-1 text-white ${
                    step === 1 
                      ? "bg-[#ff0066] hover:bg-[#cc0052]" 
                      : "bg-[#ffd700] hover:bg-[#e6c200] text-black"
                  }`}
                >
                  {step === 1 ? "Continuar al Pago" : "Confirmar Reserva"}
                </Button>
              </div>
            </div>

            {/* Right Column - Summary */}
            <div className="lg:col-span-1">
              <Card className="sticky top-20 border-2 border-[#ff0066]">
                <CardHeader className="bg-gradient-to-br from-[#ff0066] to-[#ffd700] text-white">
                  <CardTitle className="text-2xl">Resumen de Compra</CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Paquete seleccionado</p>
                    <p className="font-bold text-lg">{currentPackage.name}</p>
                    <p className="text-sm text-gray-600">{currentPackage.duration}</p>
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-600">Precio por persona:</span>
                      <span className="font-semibold">Q{currentPackage.price}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-600">Pasajeros:</span>
                      <span className="font-semibold">{numPassengers}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-600">Subtotal:</span>
                      <span className="font-semibold">Q{subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-600">IVA (13%):</span>
                      <span className="font-semibold">Q{tax.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center">
                      <span className="text-xl font-bold">Total:</span>
                      <span className="text-3xl font-bold text-[#ff0066]">Q{total.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="bg-green-50 border border-green-200 rounded-lg p-4 space-y-2">
                    <div className="flex items-center gap-2 text-green-700">
                      <CheckCircle2 className="h-5 w-5" />
                      <p className="font-semibold text-sm">Incluye:</p>
                    </div>
                    <ul className="text-sm text-gray-700 space-y-1">
                      <li>• Transporte en bus</li>
                      <li>• Hospedaje</li>
                      <li>• Comidas según paquete</li>
                      <li>• Seguro de viajero</li>
                      <li>• Guía turístico</li>
                    </ul>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <div className="flex items-start gap-2 text-yellow-700">
                      <AlertCircle className="h-5 w-5 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <p className="font-semibold mb-1">Importante:</p>
                        <p className="text-gray-700">
                          Confirmaremos la disponibilidad de tu fecha en 24 horas. Recibirás un email con toda la información.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="text-center pt-4 border-t">
                    <p className="text-sm text-gray-600 mb-2">
                      ¿Tienes preguntas?
                    </p>
                    <a href="https://wa.me/50277778888" target="_blank" rel="noopener noreferrer">
                      <Button variant="outline" size="sm" className="w-full border-[#ff0066]">
                        Contactar por WhatsApp
                      </Button>
                    </a>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </section>

      <Footer />
    </div>
  )
}