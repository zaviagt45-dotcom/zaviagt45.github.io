"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Navigation from "@/components/Navigation"
import Footer from "@/components/Footer"
import { MapPin, Clock, Users, Star, CheckCircle2, Sparkles, Shield, Heart } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-[#ffe0d0]/20 to-white">
      <Navigation />

      {/* Hero Section - Modern & Spacious */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        {/* Enhanced Background with Bus Image */}
        <div className="absolute inset-0">
          {/* Background Image */}
          <div className="absolute inset-0 bg-[url('https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cad9d21f-fa43-4f8e-9fbd-e6d07b935a7c/generated_images/professional-realistic-photograph-of-a-s-ac522d15-20251123025004.jpg')] bg-cover bg-center"></div>
          
          {/* Gradient Overlay - Lighter */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-transparent"></div>
        </div>

        <div className="relative z-10 w-full max-w-7xl mx-auto px-6 lg:px-12 py-24">
          <div className="max-w-2xl">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/95 backdrop-blur-sm rounded-full border-2 border-[#ffaa00] shadow-xl mb-8">
              <Sparkles className="h-5 w-5 text-[#ffaa00]" />
              <p className="text-sm font-bold text-gray-800">
                ¡Tu sabia decisión para viajar!
              </p>
            </div>

            {/* Main Heading */}
            <div className="space-y-6 mb-8">
              <h1 className="text-5xl md:text-7xl font-black leading-tight">
                <span className="text-white drop-shadow-2xl">Descubre</span>
                <br />
                <span className="text-white drop-shadow-2xl">El Salvador</span>
                <br />
                <span className="text-white drop-shadow-2xl">con </span>
                <span className="inline-block bg-gradient-to-r from-[#ffaa00] via-[#ff8800] to-[#ff0066] text-transparent bg-clip-text drop-shadow-2xl">
                  ZAVIA
                </span>
              </h1>

              <p className="text-lg md:text-xl text-white max-w-xl leading-relaxed font-medium drop-shadow-lg">
                Disfrutá un viaje cómodo y fresco en nuestro moderno busito. Te ofrecemos un ambiente cálido y seguro, con todas tus necesidades cubiertas para que lleguès tranquilo y sin preocupaciones.
              </p>
            </div>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/paquetes">
                <Button size="lg" className="bg-gradient-to-r from-[#ff0066] to-[#cc0052] hover:from-[#cc0052] hover:to-[#ff0066] text-white text-lg px-10 py-7 rounded-full shadow-2xl hover:shadow-[#ff0066]/50 transition-all hover:scale-105 font-bold">
                  Ver Paquetes
                </Button>
              </Link>
              <Link href="/contacto">
                <Button size="lg" variant="outline" className="border-2 border-white bg-white/95 backdrop-blur-sm text-black text-lg px-10 py-7 rounded-full hover:bg-black hover:text-white hover:border-black transition-all hover:scale-105 font-bold shadow-xl">
                  Contáctanos
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-white rounded-full flex items-start justify-center p-2">
            <div className="w-1.5 h-3 bg-white rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Features Section - Below Banner */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="group text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-[#ffaa00] to-[#ff8800] flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform">
                <Shield className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-black mb-3 text-black">100% Seguro</h3>
              <p className="text-gray-600 text-base leading-relaxed">
                Conductores profesionales y buses en perfecto estado para tu tranquilidad
              </p>
            </div>

            {/* Feature 2 */}
            <div className="group text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-[#ff0066] to-[#cc0052] flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform">
                <Heart className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-black mb-3 text-black">Comodidad Total</h3>
              <p className="text-gray-600 text-base leading-relaxed">
                Desde tu punto de partida hasta tu llegada
              </p>
            </div>

            {/* Feature 3 */}
            <div className="group text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-[#ffaa00] to-[#ff8800] flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform">
                <Sparkles className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-black mb-3 text-black">Experiencias Únicas</h3>
              <p className="text-gray-600 text-base leading-relaxed">
                Descubrí los mejores destinos y creá recuerdos inolvidables en El Salvador
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section - Modern Design */}
      <section className="py-16 px-4 bg-gradient-to-br from-[#ffe0d0]/50 via-white to-[#ffaa00]/10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <span className="inline-block px-4 py-2 bg-[#ffaa00] text-black font-bold rounded-full text-sm mb-4">
              PROCESO SIMPLE
            </span>
            <h2 className="text-4xl md:text-5xl font-black mb-4 text-black">¿Cómo Funciona?</h2>
            <p className="text-lg text-gray-700 max-w-2xl mx-auto">
              En Zavia, hacemos que viajar por El Salvador sea fácil y emocionante
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="relative bg-white rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all hover:-translate-y-2 border-4 border-[#ffaa00]">
              <div className="absolute -top-5 -left-5 w-14 h-14 rounded-full bg-gradient-to-br from-[#ffaa00] to-[#ff8800] flex items-center justify-center shadow-lg">
                <span className="text-2xl font-black text-white">1</span>
              </div>
              <div className="pt-4">
                <h3 className="text-xl font-bold mb-3 text-black">Elige tu Paquete</h3>
                <p className="text-gray-700 text-base leading-relaxed">
                  Selecciona entre nuestros dos increíbles paquetes turísticos adaptados a diferentes presupuestos y preferencias.
                </p>
              </div>
            </div>

            <div className="relative bg-white rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all hover:-translate-y-2 border-4 border-[#ff0066]">
              <div className="absolute -top-5 -left-5 w-14 h-14 rounded-full bg-gradient-to-br from-[#ff0066] to-[#cc0052] flex items-center justify-center shadow-lg">
                <span className="text-2xl font-black text-white">2</span>
              </div>
              <div className="pt-4">
                <h3 className="text-xl font-bold mb-3 text-black">Reserva y Paga</h3>
                <p className="text-gray-700 text-base leading-relaxed">
                  Completa tu reserva en línea de forma segura o contáctanos directamente para agendar tu cita y asegurar tu lugar sin estrés ni vueltas.
                </p>
              </div>
            </div>

            <div className="relative bg-white rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all hover:-translate-y-2 border-4 border-[#ffaa00]">
              <div className="absolute -top-5 -left-5 w-14 h-14 rounded-full bg-gradient-to-br from-[#ffaa00] to-[#ff8800] flex items-center justify-center shadow-lg">
                <span className="text-2xl font-black text-white">3</span>
              </div>
              <div className="pt-4">
                <h3 className="text-xl font-bold mb-3 text-black">¡Disfruta tu Viaje!</h3>
                <p className="text-gray-700 text-base leading-relaxed">
                  Sube a nuestro moderno busito y déjate llevar por las maravillas de El Salvador. ¡Nosotros nos encargamos de todo!
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Packages Section - Premium Design */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <span className="inline-block px-4 py-2 bg-[#ff0066] text-white font-bold rounded-full text-sm mb-4">
              OFERTAS ESPECIALES
            </span>
            <h2 className="text-4xl md:text-5xl font-black mb-4 text-black">Nuestros Paquetes</h2>
            <p className="text-lg text-gray-700">Elige el paquete perfecto para tu aventura</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Package 1 - Ruta del Sol */}
            <div className="group">
              <Card className="overflow-hidden bg-white rounded-3xl shadow-2xl hover:shadow-[#ffaa00]/20 transition-all duration-300 hover:scale-[1.02] border-0">
                <div className="relative h-56 overflow-hidden">
                  <img
                    src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/image-1764213018436.png?width=8000&height=8000&resize=contain"
                    alt="Ruta del Sol"
                    className="w-full h-full object-cover object-[center_65%] group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-2xl font-black text-white mb-1">paquete Ruta del Sol</h3>
                    <div className="flex items-center text-[#ffaa00]">
                      {[...Array(3)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>

                <CardContent className="p-6">
                  <div className="space-y-3 mb-5">
                    {[
                      "2 días / 2 noches",
                      "Transporte en bus climatizado",
                      "San Salvador centro histórico",
                      "Puntos turísticos",
                      "Hospedaje en Airbnb",
                      "2 cenas típicas incluidas"
                    ].map((item, i) => (
                      <div key={i} className="flex items-start space-x-3">
                        <CheckCircle2 className="h-5 w-5 text-[#ffaa00] mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700 text-sm">{item}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between py-3 px-4 bg-[#ffe0d0] rounded-2xl mb-5">
                    <div className="flex items-center space-x-2 text-gray-700">
                      <Clock className="h-4 w-4" />
                      <span className="font-semibold text-sm">2 días</span>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-700">
                      <Users className="h-4 w-4" />
                      <span className="font-semibold text-sm">9</span>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-700">
                      <MapPin className="h-4 w-4" />
                      <span className="font-semibold text-sm">Múltiples destinos</span>
                    </div>
                  </div>

                  <Link href="/paquetes/aventura-economica" className="w-full block">
                    <Button className="w-full bg-[#ffaa00] hover:bg-[#ff8800] text-black py-5 rounded-xl text-base font-bold shadow-lg hover:shadow-[#ffaa00]/50 transition-all">
                      Ver Detalles
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>

            {/* Package 2 - Escape Total 503 */}
            <div className="group">
              <Card className="overflow-hidden bg-white rounded-3xl shadow-2xl hover:shadow-[#ff00ff]/20 transition-all duration-300 hover:scale-[1.02] border-0">
                <div className="relative h-56 overflow-hidden">
                  <img
                    src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/image-1764213632116.png?width=8000&height=8000&resize=contain&quality=100"
                    alt="Escape Total 503"
                    className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute top-4 right-4">
                    <span className="bg-[#ff0066] text-white px-3 py-1 rounded-full text-xs font-bold">
                      MÁS POPULAR
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-2xl font-black text-white mb-1">Paquete Escape Premium</h3>
                    <div className="flex items-center text-[#ff0066]">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>

                <CardContent className="p-6">
                  <div className="space-y-3 mb-5">
                    {[
                      "3 días / 3 noches",
                      "Transporte en bus climatizado",
                      "San Salvador centro histórico",
                      "Puntos turísticos",
                      "Hospedaje en Airbnb",
                      "1 cena típica incluida",
                      "Actividades y tours completos"
                    ].map((item, i) => (
                      <div key={i} className="flex items-start space-x-3">
                        <CheckCircle2 className="h-5 w-5 text-[#ff0066] mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700 text-sm">{item}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between py-3 px-4 bg-[#ff0066]/10 rounded-2xl mb-5">
                    <div className="flex items-center space-x-2 text-gray-700">
                      <Clock className="h-4 w-4" />
                      <span className="font-semibold text-sm">3 días</span>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-700">
                      <Users className="h-4 w-4" />
                      <span className="font-semibold text-sm">9</span>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-700">
                      <MapPin className="h-4 w-4" />
                      <span className="font-semibold text-sm">Múltiples destinos</span>
                    </div>
                  </div>

                  <Link href="/paquetes/experiencia-premium" className="w-full block">
                    <Button className="w-full bg-[#ff0066] hover:bg-[#cc0052] text-white py-5 rounded-xl text-base font-bold shadow-lg hover:shadow-[#ff0066]/50 transition-all">
                      Ver Detalles
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section - Bold & Modern */}
      <section className="py-20 px-4 bg-gradient-to-br from-black via-gray-900 to-black relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[#ff0066]/10 to-[#ffaa00]/10"></div>
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h2 className="text-4xl md:text-5xl font-black mb-3 text-white leading-tight">
            ¿Listo para tu <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#ffaa00] to-[#ff0066]">Aventura</span>?
          </h2>
          <p className="text-[#ffaa00] font-bold text-lg mb-6">Tu sabia decisión para viajar</p>
          <p className="text-lg md:text-xl mb-10 text-gray-300 max-w-2xl mx-auto">
            Contáctanos ahora y comienza a planear tu viaje inolvidable por El Salvador
          </p>
          <Link href="/contacto">
            <Button size="lg" className="bg-gradient-to-r from-[#ff0066] to-[#cc0052] hover:from-[#cc0052] hover:to-[#ff0066] text-white px-10 py-6 rounded-full text-base font-bold shadow-2xl hover:shadow-[#ff0066]/50 transition-all hover:scale-105">
              Contáctanos Ahora
              <Sparkles className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  )
}